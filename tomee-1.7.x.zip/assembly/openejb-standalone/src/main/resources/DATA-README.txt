This directory contains binary data files for ActiveMQ, HSQLDB and
the Geronimo transaction manager.